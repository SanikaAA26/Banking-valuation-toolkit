
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def dcf_valuation(df, discount_rate=0.12, terminal_growth=0.03, tax_rate=0.25, output_dir="outputs"):
    """
    Compute a simple DCF valuation using EBITDA as a proxy for operating cash flows:
    FCF ≈ EBITDA * (1 - tax_rate) - Capex - ΔWC
    Assumptions are simplistic; adapt for your needs.
    Returns equity_value, equity_value_per_share and saves charts.
    """
    years = df['year'].values
    ebitda = df['ebitda'].values.astype(float)
    capex = df['capex'].values.astype(float)
    dwc = df['working_capital_change'].values.astype(float)
    shares = df['shares_outstanding'].iloc[-1]
    net_debt = df['net_debt'].iloc[-1]

    fcf = ebitda * (1 - tax_rate) - capex - dwc

    # Discount factors
    t = np.arange(1, len(fcf) + 1)
    disc = 1 / (1 + discount_rate) ** t
    pv_fcf = (fcf * disc).sum()

    # Terminal value using Gordon Growth on last forecast FCF
    tv = fcf[-1] * (1 + terminal_growth) / (discount_rate - terminal_growth)
    pv_tv = tv / (1 + discount_rate) ** len(fcf)

    # Enterprise value, equity value, per-share
    ev = pv_fcf + pv_tv
    equity_value = ev - net_debt
    equity_per_share = equity_value / shares if shares else np.nan

    # Save charts
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Chart 1: FCF over time
    plt.figure()
    plt.plot(years, fcf, marker="o")
    plt.title("Free Cash Flow (FCF) Over Time")
    plt.xlabel("Year")
    plt.ylabel("FCF")
    plt.savefig(f"{output_dir}/fcf_over_time.png", bbox_inches="tight")
    plt.close()

    # Chart 2: Discounted Cash Flows (including terminal value as separate point)
    dcf_series = fcf * disc
    plt.figure()
    plt.bar(years, dcf_series)
    plt.title("Present Value of Forecast FCFs")
    plt.xlabel("Year")
    plt.ylabel("PV of FCF")
    plt.savefig(f"{output_dir}/pv_fcfs.png", bbox_inches="tight")
    plt.close()

    # Write a summary
    with open(f"{output_dir}/dcf_summary.txt", "w") as f:
        f.write(f"Discount rate: {discount_rate}\n")
        f.write(f"Terminal growth: {terminal_growth}\n")
        f.write(f"Tax rate: {tax_rate}\n")
        f.write(f"PV of FCFs: {pv_fcf:.2f}\n")
        f.write(f"PV of Terminal Value: {pv_tv:.2f}\n")
        f.write(f"Enterprise Value (EV): {ev:.2f}\n")
        f.write(f"Net Debt: {net_debt:.2f}\n")
        f.write(f"Equity Value: {equity_value:.2f}\n")
        f.write(f"Shares Outstanding: {shares}\n")
        f.write(f"Equity Value per Share: {equity_per_share:.2f}\n")

    return equity_value, equity_per_share

def multiples_valuation(df):
    """
    Simple multiples valuation using last year metrics.
    Returns a dict with PE-based and EV/EBITDA-based equity values and per-share estimates.
    """
    last = df.iloc[-1]
    net_debt = float(last["net_debt"])
    shares = float(last["shares_outstanding"])
    pe = float(last["pe_multiple"])
    ev_ebitda = float(last["ev_ebitda_multiple"])

    # For illustration, approximate net income as 55% of EBITDA (after interest, tax, etc.).
    # Replace with actual net income if available.
    ebitda = float(last["ebitda"])
    approx_net_income = 0.55 * ebitda

    # Price via P/E
    market_cap_pe = approx_net_income * pe
    equity_per_share_pe = market_cap_pe / shares if shares else np.nan

    # EV via EV/EBITDA
    ev = ebitda * ev_ebitda
    market_cap_ev = ev - net_debt
    equity_per_share_ev = market_cap_ev / shares if shares else np.nan

    return {
        "market_cap_pe": market_cap_pe,
        "equity_per_share_pe": equity_per_share_pe,
        "market_cap_ev_ebitda": market_cap_ev,
        "equity_per_share_ev_ebitda": equity_per_share_ev,
    }

def run_demo(data_path="data/company_financials.csv", output_dir="outputs"):
    df = pd.read_csv(data_path)
    equity_value, equity_ps = dcf_valuation(df, discount_rate=0.12, terminal_growth=0.03, tax_rate=0.25, output_dir=output_dir)
    mults = multiples_valuation(df)

    # Save a combined summary
    with open(f"{output_dir}/valuation_summary.txt", "w") as f:
        f.write("=== DCF ===\n")
        f.write(f"Equity Value (total): {equity_value:.2f}\n")
        f.write(f"Equity Value per Share: {equity_ps:.2f}\n\n")
        f.write("=== Multiples ===\n")
        for k, v in mults.items():
            f.write(f"{k}: {v:.2f}\n")

    print("Valuation complete. Files saved in outputs/.")

if __name__ == "__main__":
    run_demo()
