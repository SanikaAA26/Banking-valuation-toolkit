
from src.valuation import run_demo
if __name__ == "__main__":
    run_demo()
