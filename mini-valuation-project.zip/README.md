
# Mini Valuation Project

A compact, beginner-friendly valuation toolkit you can put on GitHub.
It demonstrates two core methods used in finance interviews:
1) **Discounted Cash Flow (DCF)**
2) **Relative Valuation (Multiples: P/E, EV/EBITDA)**

## What it does
- Loads sample financials from `data/company_financials.csv`
- Computes an approximate Free Cash Flow (FCF) series
- Discounts FCFs to present value and adds a **Terminal Value**
- Estimates equity value and **per-share value**
- Computes a **multiples-based** valuation using P/E and EV/EBITDA
- Saves plots and text summaries in `outputs/`

> Note: This project is intentionally simple for learning. Replace assumptions with real inputs when you apply it to actual companies.

## Project structure
```
mini-valuation-project/
├── data/
│   └── company_financials.csv      # sample input
├── outputs/                        # results and charts will be saved here
├── src/
│   └── valuation.py                # valuation functions and demo
├── run_demo.py                     # entry point
├── requirements.txt
└── README.md
```

## How to run
```bash
# 1) Create a virtual environment (optional but recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run the demo
python run_demo.py
```

## Explanation (quick)
- **FCF** ≈ `EBITDA × (1 - tax_rate) - Capex - ΔWorkingCapital`
- **DCF** = Present value of forecast FCFs + Present value of **Terminal Value**
- **Terminal Value** (Gordon Growth): `FCF_last × (1 + g) / (r - g)`
- **Enterprise Value (EV)** = PV(FCFs) + PV(TV)
- **Equity Value** = EV − Net Debt
- **Equity / Share** = Equity Value / Shares Outstanding

## Customize quickly
- Update `data/company_financials.csv` with your own numbers
- Tweak `discount_rate`, `terminal_growth`, and `tax_rate` in `src/valuation.py`
- Replace approximations with real **Net Income**, **WACC**, etc.

## License
MIT — use and extend freely. Please cite this repo if you share it.
